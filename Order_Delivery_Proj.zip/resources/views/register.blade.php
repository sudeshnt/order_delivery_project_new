@extends('master')

@section('content')
  <!-- @if($message=='register_success') -->

 <!--  @endif -->


 

  
@endsection 