<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DamagedProduct extends Model
{
    protected $table = 'damaged_products';
}
