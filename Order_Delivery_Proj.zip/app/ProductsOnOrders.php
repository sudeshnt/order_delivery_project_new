<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductsOnOrders extends Model
{
    protected $table = 'products_on_order';
}
