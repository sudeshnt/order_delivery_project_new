<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductOnDelivery extends Model
{
    //
    protected $table = 'products_on_delivery';
}
