<?php $__env->startSection('content'); ?>
    <?php if(Request::path()==='reports/custom' || isset($filteredDate)): ?>
        <div class="row" style="margin:0px; padding:1%;">
            <?php /*date rage for filtering orders*/ ?>
            <div class="form-group col-md-6">
                <label>Apply Date range:</label>
                <div class="input-group">
                    <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                    </div>
                    <?php if(isset($filteredDate)): ?>
                        <input type="text" class="form-control pull-right" id="reservation" value="<?php echo e($filteredDate); ?>">
                    <?php else: ?>
                        <input type="text" class="form-control pull-right" id="reservation">
                    <?php endif; ?>
                </div>
            </div>



            <div class="col-md-4">
                <div class="row" style="margin-top: 3px;">
                    <button class="btn btn-success" style="margin-top: 22px;" onclick="function filterReports() {
                                                 window.location='<?php echo e(URL::to('reports')); ?>/'+$('#reservation').data('daterangepicker').startDate.format('YYYY-MM-DD')+','+$('#reservation').data('daterangepicker').endDate.format('YYYY-MM-DD');
                                            }
                                            filterReports();">Apply</button>
                    <button class="btn btn-danger" style="margin-top: 22px;" onclick="function clickedReset() {
                                                    window.location='<?php echo e(URL::to('reports/custom')); ?>';
                                            }
                                            clickedReset();">Reset</button>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <div style="padding: 3px; margin: 0px;" class="row">
        <div class="col-md-3 col-sm-6 col-xs-12" style="padding: 3px;">
            <div class="info-box">
                <span class="info-box-icon bg-aqua"  style="margin-right: 15px !important;"><i class="fa fa-list"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">Value of Total Sales</span>
                    <span class="info-box-number"><small>₦ </small> <?php echo e($total_sales); ?> </span>
                    <span class="info-box-number"><small style="color: #00a65a;">Total Paid  ₦ <?php echo e($total_settled); ?></small></span>
                    <span class="info-box-number"><small style="color: #dd4b39;">Total Due ₦ <?php echo e($total_due_payments); ?></small></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12" style="padding: 3px;">
            <div class="info-box">
                <span class="info-box-icon bg-red"><i class="fa fa-usd"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">Total Payments Recieved</span>
                    <span class="info-box-number"> ₦ <?php echo e($total_income); ?></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <div class="col-md-3 col-sm-6 col-xs-12" style="padding: 3px;">
            <div class="info-box">
                <span class="info-box-icon bg-green"><i class="fa fa-cart-plus"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">All Units Sold</span>
                    <span class="info-box-number"><?php echo e($total_units_sold); ?></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>

        <div class="col-md-3 col-sm-6 col-xs-12" style="padding: 3px;">
            <div class="info-box">
                <span class="info-box-icon bg-yellow"><i class="fa fa-truck"></i></span>

                <div class="info-box-content">
                    <span class="info-box-text">All Units Delivered</span>
                    <span class="info-box-number"><small>By Vehicle : </small><?php echo e($total_units_delivered_by_vehicle); ?><br><small>By Hand : </small> <?php echo e($total_units_delivered_by_hand); ?></span>
                </div>
                <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <!-- /.col -->
    </div>
    <!-- /.row -->
    <!-- Content Header (Page header) -->
   <?php /*<div>
        <section class="content-header">
            <h1> All <?php echo e($option); ?> Orders </h1>
        </section>
   </div>*/ ?>
    <div class="row" style="margin: 1%;">
        <section class="content-header" style="padding: 0px 15px 15px 15px;">
            <h1>
                All Orders <?php echo e($option); ?>

            </h1>
        </section>
        <div class="panel">
            <?php /*customer table*/ ?>
            <table id="orders_table"  class="table table-bordered table-hover allTables">
                <thead>
                <tr>
                    <th>Date</th>
                    <th style="width: 36px;">Order Code</th>
                    <th>Customer</th>
                    <th>Total</th>
                    <th>Paid</th>
                    <th>Balance</th>
                    <th style="width: 56px;">Payment Status</th>
                    <th style="width: 52px;">Delivery Status</th>
                    <th>Delivered By</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach($allOrders as $order): ?>
                    <tr<?php /* onclick="getOrderDetails('<?php echo e($order->order_code); ?>')"*/ ?>>
                        <td><?php echo e($order->order_date); ?></td>
                        <td><?php echo e($order->order_code); ?></td>
                        <td><?php echo e($order->customer_name); ?></td>
                        <td>₦ <?php echo e($order->full_amount); ?></td>
                        <td>₦ <?php echo e($order->paid_amount); ?></td>
                        <td>₦ <?php echo e($order->full_amount-$order->paid_amount); ?></td>
                        <?php if($order->isPaid): ?>
                            <td><span class="label label-success" style="font-size: small">Paid</span></td>
                        <?php else: ?>
                            <td><span class="label label-danger" style="font-size: small">Pending</span></td>
                        <?php endif; ?>
                        <?php if($order->isDelivered): ?>
                            <td><span class="label label-success" style="font-size: small">Delivered</span></td>
                        <?php else: ?>
                            <td><span class="label label-danger" style="font-size: small">Pending</span></td>
                        <?php endif; ?>
                        <?php if($order->deliveryType=='byVehicle'): ?>
                            <td><?php echo e($order->vehicle_number); ?> : <?php echo e($order->driver_name); ?></td>
                        <?php else: ?>
                            <td>delivered on the spot</td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="row" style="margin: 1%;">
        <div class="col-md-6" style="padding: 0px">
            <section class="content-header" style="padding: 0px 15px 15px 15px;">
                <h1>
                    All Sold Products <?php echo e($option); ?>

                </h1>
            </section>
            <div class="panel">
                <table id="products_table"  class="table table-bordered table-hover allTables">
                    <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Product Size</th>
                        <th>Qty</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($qty_of_products as $key => $value): ?>
                        <tr>
                            <td><?php echo e(explode("__", $key)[0]); ?></td>
                            <td><?php echo e(explode("__", $key)[1]); ?></td>
                            <td><?php echo e($value); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-md-6" style="padding: 0px 0px 0px 1%">
            <section class="content-header" style="padding: 0px 15px 15px 15px;">
                <h1>
                    All <?php echo e($option); ?> Payment Reports
                </h1>
            </section>
            <div class="panel">
                <table id="payments_table"  class="table table-bordered table-hover allTables">
                    <thead>
                    <tr>
                        <th>Payment Reference</th>
                        <th>Customer Name</th>
                        <th>Order Id</th>
                        <th>Payment Date</th>
                        <th>Amount</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($payment_reports as $payment): ?>
                        <tr>
                            <td><?php echo e($payment->payment_id); ?></td>
                            <td><?php echo e($payment->customer_name); ?></td>
                            <td><?php echo e($payment->order_code); ?></td>
                            <td><?php echo e($payment->payment_date); ?></td>
                            <td>₦ <?php echo e($payment->amount); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="row" style="margin: 1%;">
        <div class="col-md-12" style="padding: 0px">
            <section class="content-header" style="padding: 0px 15px 15px 15px;">
                <h1>
                    All Deliveries <?php echo e($option); ?>

                </h1>
            </section>
            <div class="panel">
                <table id="deliveries_table"  class="table table-bordered table-hover allTables">
                    <thead>
                    <tr>
                        <th>Delivery Date</th>
                        <th>Order Date</th>
                        <th style="width: 36px;">Order Code</th>
                        <th>Customer</th>
                        <th>Units Carried</th>
                        <th>Delivered By</th>
                        <th>Received By</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($allDeliveries as $delivery): ?>
                        <tr>
                            <td><?php echo e($delivery->delivery_time); ?></td>
                            <td><?php echo e($delivery->order_date); ?></td>
                            <td><?php echo e($delivery->order_code); ?></td>
                            <td><?php echo e($delivery->customer_name); ?></td>
                            <td><?php echo e($delivery->total_qty); ?> units of <?php echo e($delivery->num_product); ?> products</td>
                            <?php if($delivery->vehicle_number=='Vehicle Not Assigned'): ?>
                                <td>delivered on the spot</td>
                            <?php else: ?>
                                <td><?php echo e($delivery->vehicle_number); ?> : <?php echo e($delivery->driver_name); ?></td>
                            <?php endif; ?>

                            <td><?php echo e($delivery->received_by); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>

    <script>
        $(function () {
            $('#orders_table').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
        });

        $(function () {
            $('#payments_table').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
        });

        $(function () {
            $('#products_table').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
        });

        $(function () {
            $('#deliveries_table').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "order": [[ 0, "desc" ]]
            });
        });

        $('#reservation').daterangepicker();
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>