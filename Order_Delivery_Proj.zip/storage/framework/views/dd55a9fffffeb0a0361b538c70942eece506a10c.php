<?php $__env->startSection('content'); ?>
<!-- Main content -->
<section class="invoice" id="printableArea">
    <!-- title row -->
    <div class="row">
        <div class="col-xs-12">
            <h2 class="page-header">
                <i class="fa fa-globe"></i> AdminLTE, Inc.
                <?php /*<small class="pull-right">Date: 2/10/2014</small>*/ ?>
            </h2>
        </div>
        <!-- /.col -->
    </div>
    <!-- info row -->
    <div class="row invoice-info">
        <div class="col-sm-4 invoice-col">
            To
            <address>
                <strong><?php echo e($order_details->customer_name); ?></strong><br>
                <p><?php echo e($order_details->business_name); ?></p>
                <?php echo e($order_details->customer_address); ?><br>
                Phone : <?php echo e($order_details->customer_mobile); ?><br>
                Email : <?php echo e($order_details->email); ?><br>
            </address>
        </div>
        <!-- /.col -->
        <div class="col-sm-4 invoice-col">

        </div>
        <!-- /.col -->
        <div class="col-sm-4 invoice-col">
            <?php /*<b>Invoice #007612</b><br>
            <br>*/ ?>
            <b>Order ID:</b> <?php echo e($order_details->order_code); ?><br>
            <b>Order Date:</b> <?php echo e($order_details->created_at); ?><br><br>
            <?php if($order_details->deliveryType=='byHand'): ?>
                <b>Delivered On The Spot</b>
            <?php endif; ?>
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->

    <!-- Table row -->
    <div class="row">
        <div class="col-xs-12 table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Product Code</th>
                        <th>Product</th>
                        <th>Product Size</th>
                        <th>Qty</th>
                        <th>Unit Price</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach($products_on_order as $product): ?>
                    <tr>
                        <td><?php echo e($product->product_code); ?></td>
                        <td><?php echo e($product->product_name); ?></td>
                        <td><?php echo e($product->product_size); ?></td>
                        <td><?php echo e($product->qty); ?></td>
                        <td><?php echo e($product->unit_price); ?></td>
                        <td><?php echo e($product->qty*$product->unit_price); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->

    <div class="row">
        <!-- accepted payments column -->
        <div class="col-xs-6">

        </div>
        <!-- /.col -->
        <div class="col-xs-6">
            <?php /*<p class="lead">Amount Due 2/22/2014</p>*/ ?>

            <div class="table-responsive">
                <table class="table">
                    <?php /*<tr>
                        <th style="width:50%">Subtotal:</th>
                        <td>$250.30</td>
                    </tr>
                    <tr>
                        <th>Tax (9.3%)</th>
                        <td>$10.34</td>
                    </tr>
                    <tr>
                        <th>Shipping:</th>
                        <td>$5.80</td>
                    </tr>*/ ?>
                    <tr>
                        <th>Total:</th>
                        <td><?php echo e($order_details->full_amount); ?></td>
                    </tr>
                </table>
            </div>
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->

    <!-- this row will not appear when printing -->
    <div class="row no-print">
        <div class="col-xs-12">
            <a href="" onclick="printDiv('printableArea')" target="_blank" class="btn btn-default" style="float:right;"><i class="fa fa-print"></i> Print</a>
            <?php /*<button type="button" class="btn btn-success pull-right"><i class="fa fa-credit-card"></i> Submit Payment
            </button>
            <button type="button" class="btn btn-primary pull-right" style="margin-right: 5px;">
                <i class="fa fa-download"></i> Generate PDF
            </button>*/ ?>
        </div>
    </div>
</section>
<script>
    function printDiv(divName) {
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;

        document.body.innerHTML = printContents;

        window.print();

        document.body.innerHTML = originalContents;
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>